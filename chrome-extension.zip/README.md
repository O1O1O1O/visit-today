# visit-today
Browser extension to visit the current page or link in archive.today

